#include<stdio.h>
#include<stdlib.h>
#include<time.h>
void make_set(int );
void link(int ,int );
int find_set(int );
void uni(int ,int );